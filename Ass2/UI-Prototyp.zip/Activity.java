
public class Activity {
	String name;
	int value;
	
	public Activity(String name)
	{
		this.name = name;
		this.value = 5;
	}
	
	public Activity(String name, int value)
	{
		this.name = name;
		this.value = value;
	}
}
